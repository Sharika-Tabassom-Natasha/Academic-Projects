let body;
let eyeopen;
let eyeclosed;
let hair;
let flag=0;
function preload(){
  body=loadImage('modelbody.png');
  eyeopen=loadImage('eyeopen.png');
  eyeclosed=loadImage('eyesclosed.png');
  hair1=loadImage('hair2.png');
  hairicon1=loadImage('hair2.png');
  hair2=loadImage('hair3.png');
  hairicon2=loadImage('hair3.png');
}
function setup() {
  createCanvas(1500, 1000);
}


var i=230;
function draw() {
  background(220);

  image(body,0,0);


    noStroke();
    rect(530,20,150,150,25,255);
    image(hairicon1,495,0);
    hairicon1.resize(200, 200);
   

      
      
    noStroke();
    rect(770,20,150,150,25,255);
    image(hairicon2,785,10);
    hairicon2.resize(120, 170);//icon represents the little button containing the hair
   
 
  
  if(flag == 1)
  {
	  
	image(hair2,149,-5);
	  
  }
  else if(flag ==2)
  {
      image(hair1,119,-5);
  }
  else if(flag==3){
    image(body,0,0);
  }

  
  
  //BLINKING
  
  i=i-1;
  
  if(i<20){
    image(eyeclosed,162,63)
    if(i==0)
    {
      i=230;
    }
  }

  else{
      image(eyeopen,132,84);  
  }

}


  function mousePressed(){
    
    if(mouseX>=770 && mouseX<=920 && mouseY>=20 && mouseY<=170){
    
	flag = 1;
	

  }
    
    else if(mouseX>=530 && mouseX<=680 && mouseY>=20 && mouseY<=170){
		
		flag = 2;
		
    }
    else{
      flag=3;
    }
  
    
  }
